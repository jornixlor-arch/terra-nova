package com.terranova.multiplayer;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.SharedPreferences;
import android.text.InputType;
import android.view.Gravity;
import android.view.inputmethod.EditorInfo;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        prefs = getSharedPreferences("tn", MODE_PRIVATE);
        showLauncher();
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private void showLauncher() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setPadding(dp(24),dp(20),dp(24),dp(20)); root.setBackgroundColor(Color.rgb(23,35,27));
        TextView title = new TextView(this); title.setText("TERRA NOVA · MULTIPLAYER 1 НА 1"); title.setTextColor(Color.WHITE); title.setTextSize(25); title.setGravity(Gravity.CENTER); root.addView(title, new LinearLayout.LayoutParams(-1, dp(58)));
        TextView info = new TextView(this); info.setText("Введи HTTPS-адрес сервера игры. Его должен развернуть организатор матча."); info.setTextColor(Color.LTGRAY); info.setTextSize(16); info.setGravity(Gravity.CENTER); root.addView(info, new LinearLayout.LayoutParams(-1, dp(55)));
        EditText url = new EditText(this); url.setSingleLine(true); url.setTextColor(Color.WHITE); url.setHintTextColor(Color.GRAY); url.setHint("https://твой-сервер.example"); url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI); url.setImeOptions(EditorInfo.IME_ACTION_GO); url.setText(prefs.getString("url", "")); root.addView(url, new LinearLayout.LayoutParams(Math.min(dp(600), getResources().getDisplayMetrics().widthPixels-dp(48)), dp(54)));
        Button go = new Button(this); go.setText("ПОДКЛЮЧИТЬСЯ К ИГРЕ"); root.addView(go, new LinearLayout.LayoutParams(dp(300), dp(58)));
        TextView foot = new TextView(this); foot.setText("Оба игрока используют один адрес сервера. В комнате один игрок создаёт код, второй вводит тот же код."); foot.setTextColor(Color.LTGRAY); foot.setGravity(Gravity.CENTER); foot.setTextSize(14); root.addView(foot, new LinearLayout.LayoutParams(-1, dp(60)));
        go.setOnClickListener(v -> { String s=url.getText().toString().trim(); if (!s.startsWith("https://")) { url.setError("Нужен HTTPS-адрес работающего сервера"); return; } prefs.edit().putString("url",s.replaceAll("/$", "")).apply(); showGame(s.replaceAll("/$", "")); });
        setContentView(root);
    }
    private void showGame(String url) {
        WebView web = new WebView(this); web.setBackgroundColor(Color.rgb(20,27,22)); WebSettings settings=web.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setLoadWithOverviewMode(true); settings.setUseWideViewPort(true); settings.setMediaPlaybackRequiresUserGesture(false); web.setWebChromeClient(new WebChromeClient()); web.setWebViewClient(new WebViewClient(){ @Override public boolean shouldOverrideUrlLoading(WebView view, String u){ return false; }}); setContentView(web); web.loadUrl(url);
    }
    @Override public void onBackPressed() { showLauncher(); }
}
